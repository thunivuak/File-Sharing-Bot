# Telethroid

Elegant, modern and asynchronous Telegram Bot framework in Python for users and bots

# Installing

```
pip intall Telethroid
```
